package com.nexo.app;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Frame 3: "Preparando tu conversación".
 *
 * De momento solo muestra la pantalla de espera para que el flujo avance desde el Frame 2
 * (T3). Pendiente (T4): temporizador de 120 s, redirección al Frame 4, cancelación al
 * cerrar la pantalla y llamada telefónica convencional.
 */
public class WaitingActivity extends AppCompatActivity {

    public static final String EXTRA_REQUEST_ID = "request_id";

    @Override
    protected void onCreate(Bundle estadoGuardado) {
        super.onCreate(estadoGuardado);
        setContentView(R.layout.activity_waiting);

        TextView tema = findViewById(R.id.textoTemaElegido);
        CallService.Peticion peticion = CallService.obtener(this).getPeticionActiva();
        if (peticion != null) {
            tema.setText(getString(R.string.espera_tema, peticion.getTopic()));
        }
    }
}
