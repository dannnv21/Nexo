# Tareas: MVP de Solicitud de Acompañamiento ("NEXO")

- [x] **T1: Implementación de la Pantalla de Bienvenida (Frame 1)**
  - **RF cubierto:** RF-01, RNF-01, RNF-02
  - **Descripción:** Crear la vista inicial móvil con el mensaje de bienvenida y el botón grande de "Quiero hablar".
  - **Hecho cuando:** La pantalla se renderiza correctamente con tipografía grande y el botón navega hacia la pantalla de introducción del tema.

- [x] **T2: Implementación de la Validación y Bloqueo del Tema (Frame 2)**
  - **RF cubierto:** RF-02, RF-03, RF-04, RNF-01
  - **Descripción:** Desarrollar el campo de texto con límite de 100 caracteres y la lógica para deshabilitar el botón si está vacío o solo tiene espacios.
  - **Hecho cuando:** El botón de enviar permanece deshabilitado si el texto está vacío, se bloquea inmediatamente al primer clic para evitar duplicados y lanza la petición si es válido.

- [x] **T3: Lógica del Servicio de Llamadas y Manejo de Errores de Red**
  - **RF cubierto:** RF-04, RF-05, LC-02
  - **Descripción:** Programar `CallService` para gestionar la comunicación, el envío del número registrado y la cancelación automática si la red falla en el momento del envío.
  - **Hecho cuando:** Una pérdida de red al pulsar enviar cancela la operación de forma segura y devuelve al usuario el control de la pantalla.

- [x] **T4: Implementación de la Pantalla de Espera, Timeout y Cancelación (Frame 3)**
  - **RF cubierto:** RF-05, RF-06, RF-07
  - **Descripción:** Crear la vista de "Preparando tu conversación", configurar el temporizador de cuenta atrás de 2 minutos y asegurar que cerrar la pantalla cancela la petición.
  - **Hecho cuando:** Si pasan 120 segundos redirige al Frame 4, si el usuario sale se cancela la petición, y permite recibir la llamada telefónica convencional simulada en segundo plano.

- [x] **T5: Implementación de la Pantalla de Sin Voluntarios (Frame 4)**
  - **RF cubierto:** RF-06, RNF-01
  - **Descripción:** Diseñar la vista "Ahora no hay voluntarios disponibles" informando que se llamará al número registrado, con botón de retorno al inicio.
  - **Hecho cuando:** La pantalla muestra el mensaje claro de que se llamará al número registrado y permite volver a la pantalla de bienvenida.

- [x] **T6: Panel del voluntario y flujo de aceptación de peticiones**
  - Crear `VolunteerDashboardActivity` con estado vacío y tarjeta de solicitud pendiente.
  - Añadir acceso «Soy voluntario» desde bienvenida.
  - Aceptar una petición pendiente de forma atómica dentro del proceso y asignar un identificador local.
  - La pantalla de espera observa el estado de la petición y pasa automáticamente a la pantalla de aceptación cuando cambia a `accepted`.
  - Añadir `ActiveCallActivity` como pantalla posterior a la aceptación, indicando explícitamente que el audio aún no está conectado.
  - **Limitación:** la cola sigue siendo local al proceso; backend multi-dispositivo, autenticación, FCM y audio in-app quedan pendientes de configuración e integración.

- [x] **T7: Llamada telefónica tras la aceptación y portabilidad del proyecto**
  - **RF cubierto:** RF-07
  - **Descripción:** Tras aceptar, el voluntario ve el número de la persona y un botón «Llamar» que abre el marcador del teléfono (`ACTION_DIAL`, sin permiso `CALL_PHONE`). La persona mayor ve el aviso de que va a recibir una llamada normal. La URL del servidor deja de estar fija en el código (`hablamos.serverUrl` en `local.properties`).
  - **Hecho cuando:** `ActiveCallActivityTest` y `server/test_server.py` pasan, y el flujo usuario → voluntario → marcador funciona en el emulador sin cerrarse.

- [x] **T8: Llamada de voz dentro de la app**
  - **RF cubierto:** RF-07, RNF-01
  - **Descripción:** `LlamadaVoz` (lógica, sin UI) graba el micrófono y reproduce el audio del otro (PCM 16 kHz mono, tramas de 20 ms, cancelación de eco) a través del servidor (`POST /audio/{id}/{rol}`), que empareja a usuario y voluntario de una petición aceptada. `ActiveCallActivity` entra sola en la llamada, pide el permiso de micrófono y muestra "Colgar".
  - **Hecho cuando:** `ActiveCallActivityTest`, `LlamadaVozTest` y `server/test_server.py` pasan, y dos dispositivos se oyen entre sí.
