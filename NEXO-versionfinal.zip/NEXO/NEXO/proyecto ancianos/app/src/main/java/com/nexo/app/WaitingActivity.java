package com.nexo.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Pantalla de espera: controla el tiempo límite y observa el estado de la petición.
 * Al iniciarse envía la petición al servidor (POST) y después consulta su estado (GET)
 * cada pocos segundos hasta que un voluntario la acepta o se agota el tiempo.
 */
public class WaitingActivity extends AppCompatActivity {

    public static final String EXTRA_REQUEST_ID = "request_id";
    private static final String STATE_DEADLINE = "deadline_elapsed";
    private static final long INTERVALO_ESTADO_MS = 2000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long deadlineElapsed;
    private boolean finalizadaPorTimeout = false;
    private boolean navegando = false;
    private CallService.Peticion peticion;

    /** true cuando el servidor ya conoce la petición. Si el POST falla se reintenta en el siguiente ciclo. */
    private boolean enviadaAlServidor = false;
    private boolean peticionEnCurso = false;

    private final Runnable timeoutRunnable = this::finalizarPorTimeout;
    private final Runnable observarEstadoRunnable = new Runnable() {
        @Override public void run() {
            if (isFinishing() || isDestroyed() || navegando || peticion == null) return;

            if (SystemClock.elapsedRealtime() >= deadlineElapsed) {
                finalizarPorTimeout();
                return;
            }

            if (!enviadaAlServidor) {
                enviarAlServidor();
            } else {
                consultarEstado();
            }
            handler.postDelayed(this, INTERVALO_ESTADO_MS);
        }
    };

    @Override
    protected void onCreate(Bundle estadoGuardado) {
        super.onCreate(estadoGuardado);
        setContentView(R.layout.activity_waiting);

        String requestId = getIntent().getStringExtra(EXTRA_REQUEST_ID);
        peticion = CallService.obtener(getApplicationContext()).getPeticionActiva();

        if (peticion == null || requestId == null
                || !requestId.equals(peticion.getRequestId())) {
            abrirPantallaSinVoluntarios();
            return;
        }

        TextView tema = findViewById(R.id.textoTemaElegido);
        tema.setText(getString(R.string.espera_tema, peticion.getTopic()));

        if (estadoGuardado != null && estadoGuardado.containsKey(STATE_DEADLINE)) {
            deadlineElapsed = estadoGuardado.getLong(STATE_DEADLINE);
        } else {
            deadlineElapsed = SystemClock.elapsedRealtime()
                    + peticion.getTimeoutSeconds() * 1000L;
        }

        programarTimeoutRestante();
        handler.post(observarEstadoRunnable);
    }

    /** POST /requests: avisa al servidor de que este usuario busca ayuda. */
    private void enviarAlServidor() {
        if (peticionEnCurso) return;
        peticionEnCurso = true;
        ApiClient.get().crearPeticion(PeticionDto.desde(peticion)).enqueue(new Callback<PeticionDto>() {
            @Override public void onResponse(Call<PeticionDto> call, Response<PeticionDto> r) {
                peticionEnCurso = false;
                if (r.isSuccessful()) enviadaAlServidor = true;
            }

            @Override public void onFailure(Call<PeticionDto> call, Throwable t) {
                // Sin servidor o sin red: se reintenta en el siguiente ciclo mientras dure la espera.
                peticionEnCurso = false;
            }
        });
    }

    /** GET /requests/{id}: comprueba si un voluntario ya la ha aceptado. */
    private void consultarEstado() {
        if (peticionEnCurso) return;
        peticionEnCurso = true;
        ApiClient.get().obtenerPeticion(peticion.getRequestId()).enqueue(new Callback<PeticionDto>() {
            @Override public void onResponse(Call<PeticionDto> call, Response<PeticionDto> r) {
                peticionEnCurso = false;
                if (r.code() == 404) {
                    // El servidor no la conoce (p. ej. se reinició): se vuelve a enviar.
                    enviadaAlServidor = false;
                    return;
                }
                PeticionDto dto = r.body();
                if (r.isSuccessful() && dto != null
                        && CallService.ESTADO_ACEPTADA.equals(dto.status)) {
                    CallService.obtener(getApplicationContext())
                            .aceptarPeticion(peticion.getRequestId(), dto.volunteerId);
                    abrirLlamadaAceptada(peticion);
                }
            }

            @Override public void onFailure(Call<PeticionDto> call, Throwable t) {
                peticionEnCurso = false; // se vuelve a intentar en el siguiente ciclo
            }
        });
    }

    /** POST /requests/{id}/cancel. No depende de la pantalla, así que sobrevive a su cierre. */
    private void cancelarEnServidor() {
        if (peticion == null) return;
        ApiClient.get().cancelar(peticion.getRequestId()).enqueue(new Callback<PeticionDto>() {
            @Override public void onResponse(Call<PeticionDto> call, Response<PeticionDto> r) { }
            @Override public void onFailure(Call<PeticionDto> call, Throwable t) { }
        });
    }

    private void programarTimeoutRestante() {
        handler.removeCallbacks(timeoutRunnable);
        long restante = deadlineElapsed - SystemClock.elapsedRealtime();
        if (restante <= 0) {
            finalizarPorTimeout();
        } else {
            handler.postDelayed(timeoutRunnable, restante);
        }
    }

    private void abrirLlamadaAceptada(CallService.Peticion aceptada) {
        if (navegando || isFinishing() || isDestroyed()) return;
        navegando = true;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(observarEstadoRunnable);

        Intent intent = new Intent(this, ActiveCallActivity.class);
        intent.putExtra(ActiveCallActivity.EXTRA_REQUEST_ID, aceptada.getRequestId());
        intent.putExtra(ActiveCallActivity.EXTRA_TOPIC, aceptada.getTopic());
        intent.putExtra(ActiveCallActivity.EXTRA_USER_SIDE, true);
        startActivity(intent);
        finish();
    }

    private void finalizarPorTimeout() {
        if (isFinishing() || isDestroyed() || navegando) return;
        finalizadaPorTimeout = true;
        navegando = true;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(observarEstadoRunnable);

        CallService.obtener(getApplicationContext()).cancelarPeticion(peticion);
        cancelarEnServidor();
        abrirPantallaSinVoluntarios();
    }

    private void abrirPantallaSinVoluntarios() {
        navegando = true;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(observarEstadoRunnable);
        startActivity(new Intent(this, NoVolunteersActivity.class));
        finish();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putLong(STATE_DEADLINE, deadlineElapsed);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(observarEstadoRunnable);

        // Solo cancela si el usuario abandona manualmente la espera.
        // La aceptación y el timeout ya marcan navegando=true.
        if (!finalizadaPorTimeout && !navegando
                && isFinishing() && !isChangingConfigurations()) {
            CallService.obtener(getApplicationContext()).cancelarPeticion(peticion);
            cancelarEnServidor();
        }
        super.onDestroy();
    }
}
