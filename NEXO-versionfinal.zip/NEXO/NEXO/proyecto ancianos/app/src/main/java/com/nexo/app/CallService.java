package com.nexo.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

/**
 * Lógica de negocio de las llamadas de acompañamiento (T3).
 *
 * Cubre RF-04 (registrar la petición con el número de teléfono guardado),
 * RF-05 y LC-02 (si la red falla al enviar, la petición se cancela de forma segura).
 *
 * Las pantallas no contienen lógica de negocio: piden a este servicio que registre,
 * y él decide si la petición se crea o se cancela.
 */
public class CallService {

    public static final String ESTADO_BUSCANDO = "searching";
    public static final String ESTADO_CANCELADA = "cancelled";
    public static final String ESTADO_ACEPTADA = "accepted";
    private String voluntarioAsignado;

    public static final int LIMITE_CARACTERES = 100;
    public static final int TIMEOUT_SEGUNDOS = 120;

    /**
     * Número registrado del dispositivo. En el MVP se asume precargado (la creación de
     * cuentas está fuera de alcance); es el mismo que aparece en el modelo de datos del plan.
     */
    public static final String NUMERO_REGISTRADO_POR_DEFECTO = "+34600111222";

    /** Permite sustituir la comprobación de red (en pruebas, o por otra implementación). */
    public interface ComprobadorRed {
        boolean hayConexion();
    }

    /** Se lanza cuando no hay red en el momento del envío. La petición NO queda registrada. */
    public static class SinConexionException extends Exception {
        public SinConexionException() {
            super("No hay conexión de red en el momento del envío");
        }
    }

    /** Petición de acompañamiento. Sigue el modelo de datos JSON del plan técnico. */
    public static class Peticion {
        private final String requestId;
        private final String userPhone;
        private final String topic;
        private final String createdAt;
        private final int timeoutSeconds;
        private String status;

        Peticion(String requestId, String userPhone, String topic, String createdAt,
                 int timeoutSeconds, String status) {
            this.requestId = requestId;
            this.userPhone = userPhone;
            this.topic = topic;
            this.createdAt = createdAt;
            this.timeoutSeconds = timeoutSeconds;
            this.status = status;
        }

        public String getRequestId() { return requestId; }
        public String getUserPhone() { return userPhone; }
        public String getTopic() { return topic; }
        public String getCreatedAt() { return createdAt; }
        public int getTimeoutSeconds() { return timeoutSeconds; }
        public String getStatus() { return status; }

        public boolean estaCancelada() { return ESTADO_CANCELADA.equals(status); }

        public JSONObject toJson() {
            try {
                JSONObject json = new JSONObject();
                json.put("request_id", requestId);
                json.put("user_phone", userPhone);
                json.put("topic", topic);
                json.put("status", status);
                json.put("created_at", createdAt);
                json.put("timeout_seconds", timeoutSeconds);
                return json;
            } catch (JSONException e) {
                // No ocurre con claves y valores válidos.
                throw new IllegalStateException(e);
            }
        }
    }

    // ---------- Acceso compartido entre pantallas ----------

    private static CallService instancia;

    /** Devuelve el servicio compartido de la app (lo usan TopicActivity y WaitingActivity). */
    public static synchronized CallService obtener(Context contexto) {
        if (instancia == null) {
            instancia = new CallService(
                    new ComprobadorRedAndroid(contexto.getApplicationContext()),
                    NUMERO_REGISTRADO_POR_DEFECTO);
        }
        return instancia;
    }

    /** Solo para pruebas: instala un servicio concreto (o null para volver al de por defecto). */
    static synchronized void establecerParaPruebas(CallService servicio) {
        instancia = servicio;
    }

    // ---------- Servicio ----------

    private final ComprobadorRed red;
    private final String numeroRegistrado;
    private Peticion peticionActiva;

    public CallService(ComprobadorRed red, String numeroRegistrado) {
        this.red = red;
        this.numeroRegistrado = numeroRegistrado;
    }

    /**
     * Registra una petición de acompañamiento con el número guardado (RF-04).
     *
     * @throws SinConexionException si no hay red al enviar (RF-05, LC-02). En ese caso no se
     *                              crea ninguna petición y el usuario recupera el control.
     * @throws IllegalArgumentException si el tema está vacío, es solo espacios o pasa de 100.
     */
    public synchronized Peticion registrarPeticion(String tema) throws SinConexionException {
        if (!esTemaValido(tema)) {
            throw new IllegalArgumentException("Tema no válido");
        }
        if (!hayRed()) {
            peticionActiva = null;
            throw new SinConexionException();
        }
        peticionActiva = new Peticion(
                "req_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12),
                numeroRegistrado,
                tema.trim(),
                ahoraIso(),
                TIMEOUT_SEGUNDOS,
                ESTADO_BUSCANDO);
        return peticionActiva;
    }

    /** Cancela una petición (RF-05). Es seguro llamarlo varias veces o con null. */
    public synchronized void cancelarPeticion(Peticion peticion) {
        if (peticion == null) {
            return;
        }
        peticion.status = ESTADO_CANCELADA;
        if (peticion == peticionActiva) {
            peticionActiva = null;
        }
    }

    /** Acepta una petición pendiente de forma atómica dentro de este proceso. */
    public synchronized boolean aceptarPeticion(String requestId, String volunteerId) {
        if (peticionActiva == null || requestId == null || volunteerId == null
                || !requestId.equals(peticionActiva.getRequestId())
                || !ESTADO_BUSCANDO.equals(peticionActiva.getStatus())) {
            return false;
        }
        peticionActiva.status = ESTADO_ACEPTADA;
        voluntarioAsignado = volunteerId;
        return true;
    }

    public synchronized String getVoluntarioAsignado() { return voluntarioAsignado; }

    /** Petición en curso, o null si no hay ninguna. */
    public synchronized Peticion getPeticionActiva() {
        return peticionActiva;
    }

    static boolean esTemaValido(String tema) {
        return tema != null && !tema.trim().isEmpty() && tema.length() <= LIMITE_CARACTERES;
    }

    private boolean hayRed() {
        try {
            return red != null && red.hayConexion();
        } catch (RuntimeException e) {
            // Si ni siquiera se puede comprobar, se trata como "sin red": lo más seguro.
            return false;
        }
    }

    private static String ahoraIso() {
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        formato.setTimeZone(TimeZone.getTimeZone("UTC"));
        return formato.format(new Date());
    }

    /** Comprobación de red real con ConnectivityManager. */
    private static class ComprobadorRedAndroid implements ComprobadorRed {
        private final Context contexto;

        ComprobadorRedAndroid(Context contexto) {
            this.contexto = contexto;
        }

        @Override
        @SuppressWarnings("deprecation")
        public boolean hayConexion() {
            ConnectivityManager gestor =
                    (ConnectivityManager) contexto.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (gestor == null) {
                return false;
            }
            NetworkInfo info = gestor.getActiveNetworkInfo();
            return info != null && info.isConnected();
        }
    }
}
