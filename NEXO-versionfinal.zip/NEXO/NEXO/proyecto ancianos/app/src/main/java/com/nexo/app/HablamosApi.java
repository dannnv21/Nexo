package com.nexo.app;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/** Endpoints del servidor local (ver server/server.py). */
public interface HablamosApi {

    /** Cuerpo de la aceptación: quién acepta. */
    class AceptarBody {
        @SerializedName("volunteer_id") public final String volunteerId;
        public AceptarBody(String volunteerId) { this.volunteerId = volunteerId; }
    }

    /** El usuario empieza a buscar ayuda. Es idempotente por request_id. */
    @POST("requests")
    Call<PeticionDto> crearPeticion(@Body PeticionDto peticion);

    /** Estado actual de una petición (lo consulta el usuario mientras espera). */
    @GET("requests/{id}")
    Call<PeticionDto> obtenerPeticion(@Path("id") String id);

    /** Lista de peticiones, filtrable por estado (lo consulta el voluntario). */
    @GET("requests")
    Call<List<PeticionDto>> listarPeticiones(@Query("status") String status);

    /** El voluntario acepta. 409 si otra persona se adelantó o ya se canceló. */
    @POST("requests/{id}/accept")
    Call<PeticionDto> aceptar(@Path("id") String id, @Body AceptarBody body);

    /** El usuario cancela o se agota el tiempo. */
    @POST("requests/{id}/cancel")
    Call<PeticionDto> cancelar(@Path("id") String id);
}
