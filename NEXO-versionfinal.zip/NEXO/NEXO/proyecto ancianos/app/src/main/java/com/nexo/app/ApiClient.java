package com.nexo.app;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Cliente Retrofit compartido.
 *
 * La dirección del servidor NO está escrita aquí: viene de BuildConfig.SERVER_URL, que se
 * genera en app/build.gradle. Por defecto es http://10.0.2.2:3000/ (dentro del emulador,
 * 10.0.2.2 es el ordenador que ejecuta el emulador, sea cual sea). Con un móvil físico se
 * cambia en local.properties con la línea: hablamos.serverUrl=http://IP_DE_TU_PC:3000/
 */
public final class ApiClient {
    public static final String BASE_URL = normalizar(BuildConfig.SERVER_URL);

    private static HablamosApi api;

    private ApiClient() { }

    public static synchronized HablamosApi get() {
        if (api == null) {
            OkHttpClient cliente = new OkHttpClient.Builder()
                    .connectTimeout(5, TimeUnit.SECONDS)
                    .readTimeout(10, TimeUnit.SECONDS)
                    .build();
            api = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(cliente)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                    .create(HablamosApi.class);
        }
        return api;
    }

    /** Retrofit exige que la URL base termine en "/"; si se olvida, la app se cerraría al arrancar. */
    static String normalizar(String url) {
        String limpia = url == null ? "" : url.trim();
        if (limpia.isEmpty()) {
            limpia = "http://10.0.2.2:3000/";
        }
        if (!limpia.startsWith("http://") && !limpia.startsWith("https://")) {
            limpia = "http://" + limpia;
        }
        return limpia.endsWith("/") ? limpia : limpia + "/";
    }
}
