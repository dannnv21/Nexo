package com.nexo.app;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Pantalla de la llamada, tras aceptar una petición (RF-07).
 *
 * Al abrirse, los dos móviles (persona mayor y voluntario) entran solos en la llamada de voz
 * de la app ({@link LlamadaVoz}); la persona mayor no tiene que pulsar nada. Solo hay un botón
 * grande para colgar. El voluntario tiene además «Llamar por teléfono» (línea normal) por si
 * la llamada por la app falla.
 *
 * Esta pantalla no tiene lógica de llamada (Constitución, principio 3): solo pinta el estado.
 */
public class ActiveCallActivity extends AppCompatActivity implements LlamadaVoz.Oyente {
    public static final String EXTRA_REQUEST_ID = "REQUEST_ID";
    public static final String EXTRA_TOPIC = "TOPIC";
    public static final String EXTRA_USER_SIDE = "USER_SIDE";
    public static final String EXTRA_USER_PHONE = "USER_PHONE";

    private static final int CODIGO_PERMISO_MICRO = 41;

    /** Crea la llamada. Las pruebas la sustituyen para no usar red ni audio reales. */
    interface FabricaLlamada {
        LlamadaVoz crear(Context contexto, String requestId, String rol, LlamadaVoz.Oyente oyente);
    }

    static FabricaLlamada fabrica = LlamadaVoz::new;

    private boolean ladoUsuario;
    private String requestId;
    private LlamadaVoz llamada;
    private TextView textoEstado;
    private Button botonColgar;
    private Button botonReintentar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_active_call);

        ladoUsuario = getIntent().getBooleanExtra(EXTRA_USER_SIDE, false);
        requestId = getIntent().getStringExtra(EXTRA_REQUEST_ID);
        String telefono = getIntent().getStringExtra(EXTRA_USER_PHONE);

        ((TextView) findViewById(R.id.textoTituloLlamada)).setText(ladoUsuario
                ? R.string.llamada_titulo_usuario : R.string.llamada_titulo_voluntario);

        String tema = getIntent().getStringExtra(EXTRA_TOPIC);
        ((TextView) findViewById(R.id.textoTemaLlamada)).setText(getString(R.string.llamada_tema,
                tema == null || tema.trim().isEmpty() ? getString(R.string.llamada_tema_vacio) : tema));

        textoEstado = findViewById(R.id.textoEstadoLlamada);

        TextView aviso = findViewById(R.id.textoAvisoLlamada);
        aviso.setTextSize(ladoUsuario ? 20 : 16);
        aviso.setText(ladoUsuario
                ? getString(R.string.llamada_aviso_usuario)
                : getString(R.string.llamada_aviso_voluntario,
                        telefono != null ? telefono : "desconocido"));

        botonColgar = findViewById(R.id.botonColgar);
        botonColgar.setOnClickListener(v -> colgarYSalir());

        botonReintentar = findViewById(R.id.botonReintentar);
        botonReintentar.setOnClickListener(v -> pedirPermisoEIniciar());

        Button llamar = findViewById(R.id.botonLlamar);
        if (!ladoUsuario && esTelefonoValido(telefono)) {
            llamar.setOnClickListener(v -> abrirMarcador(telefono));
        } else {
            // Solo el voluntario con un número válido tiene el botón de línea telefónica.
            ((ViewGroup) llamar.getParent()).removeView(llamar);
        }

        if (requestId == null) {
            textoEstado.setText("No se puede llamar: falta la petición.");
            botonColgar.setText(R.string.llamada_volver_inicio);
            return;
        }
        pedirPermisoEIniciar();
    }

    // ---------- Llamada ----------

    private void pedirPermisoEIniciar() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
            iniciarLlamada(true);
        } else {
            textoEstado.setText("Para hablar, permite usar el micrófono.");
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, CODIGO_PERMISO_MICRO);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CODIGO_PERMISO_MICRO) {
            boolean concedido = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            // Sin permiso se entra igualmente para poder escuchar.
            iniciarLlamada(concedido);
        }
    }

    private void iniciarLlamada(boolean conMicrofono) {
        if (llamada != null && llamada.estaActiva()) return;
        botonReintentar.setVisibility(View.GONE);
        botonColgar.setText(R.string.llamada_colgar);
        llamada = fabrica.crear(this, requestId,
                ladoUsuario ? LlamadaVoz.ROL_USUARIO : LlamadaVoz.ROL_VOLUNTARIO, this);
        llamada.iniciar(conMicrofono);
    }

    @Override
    public void alCambiarEstado(LlamadaVoz.Estado estado, String mensaje) {
        if (isFinishing() || isDestroyed()) return;
        switch (estado) {
            case CONECTANDO:
                textoEstado.setText(ladoUsuario
                        ? "Conectando con el voluntario…"
                        : "Llamando… esperando a que la persona entre en la llamada.");
                break;
            case EN_LLAMADA:
                textoEstado.setText(mensaje == null ? "En llamada" : "En llamada\n" + mensaje);
                break;
            case FINALIZADA:
            case ERROR:
                textoEstado.setText(mensaje != null ? mensaje : "La llamada ha terminado.");
                botonColgar.setText(R.string.llamada_volver_inicio);
                botonReintentar.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void colgarYSalir() {
        if (llamada != null) llamada.colgar();
        // La persona mayor valora la llamada; el voluntario vuelve directamente al inicio.
        Intent siguiente = new Intent(this,
                ladoUsuario && requestId != null ? RatingActivity.class : WelcomeActivity.class);
        siguiente.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(siguiente);
        finish();
    }

    @Override
    protected void onDestroy() {
        // Salir de la pantalla (Atrás, cerrar la app) siempre cuelga: no se queda el micro abierto.
        if (llamada != null) llamada.colgar();
        super.onDestroy();
    }

    // ---------- Llamada por línea telefónica (alternativa del voluntario) ----------

    /** Un número es válido si tiene al menos 3 dígitos y solo contiene +, dígitos o espacios. */
    static boolean esTelefonoValido(String telefono) {
        if (telefono == null) return false;
        String limpio = telefono.trim();
        return limpio.matches("\\+?[0-9 ]{3,20}");
    }

    /** Intent que abre el marcador con el número escrito, sin realizar la llamada todavía. */
    static Intent crearIntentMarcador(String telefono) {
        return new Intent(Intent.ACTION_DIAL,
                Uri.fromParts("tel", telefono.replace(" ", ""), null));
    }

    private void abrirMarcador(String telefono) {
        try {
            startActivity(crearIntentMarcador(telefono));
        } catch (ActivityNotFoundException e) {
            // Algunos emuladores (tablets, imágenes ATD) no tienen app de teléfono: avisamos, no crasheamos.
            Toast.makeText(this, "Este dispositivo no tiene app de teléfono. Número: " + telefono,
                    Toast.LENGTH_LONG).show();
        }
    }
}
