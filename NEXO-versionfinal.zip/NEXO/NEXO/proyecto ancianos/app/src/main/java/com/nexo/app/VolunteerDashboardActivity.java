package com.nexo.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.UUID;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Panel de voluntario. Consulta al servidor cada pocos segundos (GET /requests?status=searching)
 * mientras la pantalla está visible, y permite aceptar una petición (POST /requests/{id}/accept).
 */
public class VolunteerDashboardActivity extends AppCompatActivity {
    private static final long INTERVALO_SONDEO_MS = 3000L;

    /** Identificador de este voluntario (distinto en cada arranque de la app). */
    private static final String VOLUNTARIO_ID =
            "voluntario_" + UUID.randomUUID().toString().substring(0, 8);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout requestsContainer;
    private TextView statusText;
    private boolean consultando = false;
    private boolean aceptando = false;

    private final Runnable sondeo = new Runnable() {
        @Override public void run() {
            consultarPeticiones();
            handler.postDelayed(this, INTERVALO_SONDEO_MS);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = dp(24);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundResource(R.drawable.fondo_degradado);
        TextView title = new TextView(this);
        title.setText("Modo voluntario"); title.setTextSize(30);
        title.setTextColor(getColor(R.color.texto_principal)); title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Peticiones de personas que esperan para hablar");
        subtitle.setTextSize(18); subtitle.setTextColor(getColor(R.color.texto_secundario));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(10);
        root.addView(subtitle, sp);
        statusText = new TextView(this); statusText.setTextSize(18); statusText.setTextColor(getColor(R.color.texto_principal));
        statusText.setText("Buscando peticiones…");
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2); stp.topMargin = dp(28);
        root.addView(statusText, stp);
        requestsContainer = new LinearLayout(this); requestsContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(16);
        root.addView(requestsContainer, lp);
        Button refresh = new Button(this); refresh.setText("Actualizar peticiones"); estiloSecundario(refresh);
        refresh.setOnClickListener(v -> consultarPeticiones());
        root.addView(refresh, refresh.getLayoutParams());
        Button back = new Button(this); back.setText("Volver"); estiloSecundario(back); back.setOnClickListener(v -> finish());
        root.addView(back, back.getLayoutParams());
        setContentView(root);
    }

    // El sondeo solo corre mientras la pantalla es visible.
    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(sondeo);
        handler.post(sondeo);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(sondeo);
        super.onPause();
    }

    /** GET /requests?status=searching */
    private void consultarPeticiones() {
        if (consultando || aceptando) return;
        consultando = true;
        ApiClient.get().listarPeticiones(CallService.ESTADO_BUSCANDO)
                .enqueue(new Callback<List<PeticionDto>>() {
            @Override public void onResponse(Call<List<PeticionDto>> call,
                                             Response<List<PeticionDto>> r) {
                consultando = false;
                if (isFinishing() || isDestroyed()) return;
                if (r.isSuccessful() && r.body() != null) {
                    pintarPeticiones(r.body());
                } else {
                    statusText.setText("El servidor respondió con un error (" + r.code() + ").");
                }
            }

            @Override public void onFailure(Call<List<PeticionDto>> call, Throwable t) {
                consultando = false;
                if (isFinishing() || isDestroyed()) return;
                requestsContainer.removeAllViews();
                statusText.setText("No se pudo conectar con el servidor. Reintentando…");
            }
        });
    }

    private void pintarPeticiones(List<PeticionDto> peticiones) {
        requestsContainer.removeAllViews();
        if (peticiones.isEmpty()) {
            statusText.setText("No hay peticiones pendientes.");
            return;
        }
        statusText.setText(peticiones.size() == 1
                ? "Hay una persona esperando una conversación."
                : "Hay " + peticiones.size() + " personas esperando una conversación.");

        for (PeticionDto request : peticiones) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackgroundResource(R.drawable.fondo_tarjeta_voluntario);
            TextView topic = new TextView(this); topic.setText("Tema de conversación\n" + request.topic);
            topic.setTextSize(20); topic.setTextColor(getColor(R.color.texto_principal)); topic.setTypeface(null, android.graphics.Typeface.BOLD);
            card.addView(topic);
            TextView detail = new TextView(this);
            detail.setText("Solicitud: " + request.requestId + "\nEspera máxima: " + request.timeoutSeconds + " segundos");
            detail.setTextSize(15); detail.setTextColor(getColor(R.color.texto_secundario));
            LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(-1, -2); detailParams.topMargin = dp(12); card.addView(detail, detailParams);
            Button accept = new Button(this); accept.setText("Aceptar llamada"); estiloPrimario(accept);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2); ap.topMargin = dp(16); card.addView(accept, ap);
            accept.setOnClickListener(v -> aceptarPeticion(request, accept));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.bottomMargin = dp(12);
            requestsContainer.addView(card, cp);
        }
    }

    /** POST /requests/{id}/accept: cambia el estado en el servidor a "accepted". */
    private void aceptarPeticion(PeticionDto request, Button boton) {
        if (aceptando) return;
        aceptando = true;
        boton.setEnabled(false);
        ApiClient.get().aceptar(request.requestId, new HablamosApi.AceptarBody(VOLUNTARIO_ID))
                .enqueue(new Callback<PeticionDto>() {
            @Override public void onResponse(Call<PeticionDto> call, Response<PeticionDto> r) {
                aceptando = false;
                if (isFinishing() || isDestroyed()) return;
                if (r.isSuccessful()) {
                    Intent intent = new Intent(VolunteerDashboardActivity.this, ActiveCallActivity.class);
                    intent.putExtra(ActiveCallActivity.EXTRA_REQUEST_ID, request.requestId);
                    intent.putExtra(ActiveCallActivity.EXTRA_TOPIC, request.topic);
                    // Número de la persona mayor: el voluntario lo usa para llamarla (RF-07).
                    PeticionDto aceptada = r.body();
                    intent.putExtra(ActiveCallActivity.EXTRA_USER_PHONE,
                            aceptada != null && aceptada.userPhone != null
                                    ? aceptada.userPhone : request.userPhone);
                    startActivity(intent);
                } else if (r.code() == 409 || r.code() == 404) {
                    Toast.makeText(VolunteerDashboardActivity.this,
                            "La petición ya no está disponible.", Toast.LENGTH_SHORT).show();
                    consultarPeticiones();
                } else {
                    boton.setEnabled(true);
                    Toast.makeText(VolunteerDashboardActivity.this,
                            "Error del servidor (" + r.code() + ").", Toast.LENGTH_SHORT).show();
                }
            }

            @Override public void onFailure(Call<PeticionDto> call, Throwable t) {
                aceptando = false;
                if (isFinishing() || isDestroyed()) return;
                boton.setEnabled(true);
                Toast.makeText(VolunteerDashboardActivity.this,
                        "No se pudo conectar con el servidor.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void estiloPrimario(Button b) {
        b.setBackgroundResource(R.drawable.boton_primario);
        b.setTextColor(getColor(R.color.boton_texto));
        b.setTextSize(20);
        b.setAllCaps(false);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setMinHeight(dp(64));
        b.setStateListAnimator(null);
    }

    private void estiloSecundario(Button b) {
        b.setBackgroundResource(R.drawable.boton_secundario);
        b.setTextColor(getColor(R.color.boton_fondo));
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setMinHeight(dp(56));
        b.setStateListAnimator(null);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
