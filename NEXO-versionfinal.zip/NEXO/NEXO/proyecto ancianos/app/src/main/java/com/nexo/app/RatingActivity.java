package com.nexo.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Valoración de la llamada (la ve la persona mayor al colgar) y mensaje de agradecimiento.
 * Son dos estados de la misma pantalla: primero se elige cómo fue la llamada y,
 * al enviar, aparece «Gracias por compartirlo».
 *
 * Por ahora la valoración solo se queda en el móvil (el servidor aún no tiene endpoint para ella).
 */
public class RatingActivity extends AppCompatActivity {

    public static final int VALORACION_NINGUNA = 0;
    public static final int VALORACION_MAL = 1;
    public static final int VALORACION_REGULAR = 2;
    public static final int VALORACION_BIEN = 3;

    private static final String ESTADO_VALORACION = "valoracion";
    private static final String ESTADO_ENVIADA = "enviada";

    private View opcionMal;
    private View opcionRegular;
    private View opcionBien;
    private Button botonEnviar;
    private View grupoValoracion;
    private View grupoGracias;

    private int valoracion = VALORACION_NINGUNA;
    private boolean enviada = false;

    @Override
    protected void onCreate(Bundle estadoGuardado) {
        super.onCreate(estadoGuardado);
        setContentView(R.layout.activity_rating);

        grupoValoracion = findViewById(R.id.grupoValoracion);
        grupoGracias = findViewById(R.id.grupoGracias);
        opcionMal = findViewById(R.id.opcionMal);
        opcionRegular = findViewById(R.id.opcionRegular);
        opcionBien = findViewById(R.id.opcionBien);
        botonEnviar = findViewById(R.id.botonEnviarValoracion);

        opcionMal.setOnClickListener(v -> elegir(VALORACION_MAL));
        opcionRegular.setOnClickListener(v -> elegir(VALORACION_REGULAR));
        opcionBien.setOnClickListener(v -> elegir(VALORACION_BIEN));

        botonEnviar.setOnClickListener(v -> enviar());
        findViewById(R.id.botonSaltarValoracion).setOnClickListener(v -> volverAlInicio());
        findViewById(R.id.botonVolverInicioGracias).setOnClickListener(v -> volverAlInicio());

        if (estadoGuardado != null) {
            valoracion = estadoGuardado.getInt(ESTADO_VALORACION, VALORACION_NINGUNA);
            enviada = estadoGuardado.getBoolean(ESTADO_ENVIADA, false);
        }
        pintar();
    }

    private void elegir(int nueva) {
        valoracion = nueva;
        pintar();
    }

    private void enviar() {
        if (valoracion == VALORACION_NINGUNA) {
            return;
        }
        enviada = true;
        pintar();
    }

    private void pintar() {
        opcionMal.setSelected(valoracion == VALORACION_MAL);
        opcionRegular.setSelected(valoracion == VALORACION_REGULAR);
        opcionBien.setSelected(valoracion == VALORACION_BIEN);
        botonEnviar.setEnabled(valoracion != VALORACION_NINGUNA);

        grupoValoracion.setVisibility(enviada ? View.GONE : View.VISIBLE);
        grupoGracias.setVisibility(enviada ? View.VISIBLE : View.GONE);
    }

    private void volverAlInicio() {
        Intent inicio = new Intent(this, WelcomeActivity.class);
        inicio.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(inicio);
        finish();
    }

    @Override
    protected void onSaveInstanceState(Bundle salida) {
        salida.putInt(ESTADO_VALORACION, valoracion);
        salida.putBoolean(ESTADO_ENVIADA, enviada);
        super.onSaveInstanceState(salida);
    }
}
