package com.nexo.app;

import com.google.gson.annotations.SerializedName;

/** Petición tal y como viaja por la red (JSON del modelo de datos del plan técnico). */
public class PeticionDto {
    @SerializedName("request_id") public String requestId;
    @SerializedName("user_phone") public String userPhone;
    @SerializedName("topic") public String topic;
    @SerializedName("status") public String status;
    @SerializedName("created_at") public String createdAt;
    @SerializedName("timeout_seconds") public int timeoutSeconds;
    @SerializedName("volunteer_id") public String volunteerId;

    public static PeticionDto desde(CallService.Peticion p) {
        PeticionDto dto = new PeticionDto();
        dto.requestId = p.getRequestId();
        dto.userPhone = p.getUserPhone();
        dto.topic = p.getTopic();
        dto.status = p.getStatus();
        dto.createdAt = p.getCreatedAt();
        dto.timeoutSeconds = p.getTimeoutSeconds();
        return dto;
    }
}
