package com.nexo.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Llamada de voz entre la persona mayor y el voluntario, dentro de la app (RF-07).
 *
 * Funcionamiento: los dos móviles se conectan al servidor (POST /audio/{id}/{rol}); cuando han
 * llegado ambos, el servidor responde 200 y desde ese momento reenvía el audio de uno al otro.
 * El audio viaja en bruto: PCM de 16 bits, 16 kHz, mono (32 KB/s), en tramas de 20 ms.
 *
 * No depende de ninguna librería externa ni de ninguna pantalla: la UI solo llama a
 * iniciar()/colgar() y recibe los cambios de estado por {@link Oyente} en el hilo principal.
 */
public class LlamadaVoz {

    private static final String TAG = "LlamadaVoz";

    public static final String ROL_USUARIO = "usuario";
    public static final String ROL_VOLUNTARIO = "voluntario";

    static final int FRECUENCIA = 16000;
    static final int BYTES_TRAMA = FRECUENCIA * 2 / 50;          // 20 ms = 640 bytes
    /** Si se acumula más de 300 ms de audio sin reproducir, se descarta para no ir con retraso. */
    static final int MAX_RETRASO_BYTES = FRECUENCIA * 2 * 3 / 10;
    private static final int ESPERA_CONEXION_MS = 5000;
    /** El servidor espera hasta 90 s a la otra persona; aquí damos un poco más de margen. */
    private static final int ESPERA_PAREJA_MS = 100_000;

    public enum Estado { CONECTANDO, EN_LLAMADA, FINALIZADA, ERROR }

    public interface Oyente {
        void alCambiarEstado(Estado estado, String mensaje);
    }

    private final Context contexto;
    private final String requestId;
    private final String rol;
    private final Oyente oyente;
    private final Handler principal = new Handler(Looper.getMainLooper());

    private volatile boolean activa = false;
    private volatile boolean colgadaPorMi = false;
    private volatile Socket socket;
    private volatile Estado estado = null;
    private Thread hiloRed;

    public LlamadaVoz(Context contexto, String requestId, String rol, Oyente oyente) {
        this.contexto = contexto.getApplicationContext();
        this.requestId = requestId;
        this.rol = rol;
        this.oyente = oyente;
    }

    /** Arranca la llamada en segundo plano. Si no hay permiso de micrófono, solo se escucha. */
    public synchronized void iniciar(boolean conMicrofono) {
        if (activa) return;
        activa = true;
        colgadaPorMi = false;
        avisar(Estado.CONECTANDO, null);
        hiloRed = new Thread(() -> ejecutar(conMicrofono), "llamada-red");
        hiloRed.start();
    }

    /** Cuelga. Seguro llamarlo varias veces o antes de que conecte. */
    public void colgar() {
        colgadaPorMi = true;
        activa = false;
        cerrarSocket();
    }

    public boolean estaActiva() { return activa; }

    // ---------------------------------------------------------------------------------------

    private void ejecutar(boolean conMicrofono) {
        AudioManager audio = (AudioManager) contexto.getSystemService(Context.AUDIO_SERVICE);
        int modoAnterior = audio != null ? audio.getMode() : AudioManager.MODE_NORMAL;
        boolean altavozAnterior = audio != null && audio.isSpeakerphoneOn();
        AudioTrack altavoz = null;
        Thread hiloMicro = null;
        String mensajeFinal = null;
        boolean error = false;
        try {
            Socket s = new Socket();
            socket = s;
            URL base = new URL(ApiClient.BASE_URL);
            int puerto = base.getPort() != -1 ? base.getPort() : base.getDefaultPort();
            s.connect(new InetSocketAddress(base.getHost(), puerto), ESPERA_CONEXION_MS);
            s.setTcpNoDelay(true);
            s.setSoTimeout(ESPERA_PAREJA_MS);

            OutputStream salida = s.getOutputStream();
            DataInputStream entrada = new DataInputStream(s.getInputStream());
            salida.write(crearCabecera(requestId, rol, base.getHost()).getBytes(StandardCharsets.UTF_8));
            salida.flush();

            int codigo = leerCodigoRespuesta(entrada);
            if (codigo != 200) {
                error = codigo != 408;
                mensajeFinal = mensajeParaCodigo(codigo);
                return;
            }
            s.setSoTimeout(0);
            if (!activa) return;

            if (audio != null) {
                audio.setMode(AudioManager.MODE_IN_COMMUNICATION);
                audio.setSpeakerphoneOn(true); // manos libres: más fácil para personas mayores
            }
            altavoz = crearAltavoz();
            altavoz.play();
            avisar(Estado.EN_LLAMADA, conMicrofono ? null
                    : "Sin permiso de micrófono: puedes escuchar, pero no te oirán.");

            if (conMicrofono) {
                hiloMicro = new Thread(() -> enviarMicrofono(salida), "llamada-micro");
                hiloMicro.start();
            }

            byte[] trama = new byte[BYTES_TRAMA];
            while (activa) {
                entrada.readFully(trama);              // tramas completas: el audio no se desalinea
                while (entrada.available() > MAX_RETRASO_BYTES) {
                    entrada.readFully(trama);          // vamos con retraso: se salta audio viejo
                }
                altavoz.write(trama, 0, trama.length);
            }
        } catch (IOException e) {
            if (!colgadaPorMi) {
                if (estado == Estado.EN_LLAMADA) {
                    mensajeFinal = "La otra persona ha colgado.";
                } else {
                    error = true;
                    mensajeFinal = "No se pudo conectar con el servidor de llamadas.";
                }
            }
            Log.i(TAG, "Fin de la llamada: " + e);
        } catch (RuntimeException e) {
            // Cualquier fallo de audio (p. ej. un emulador sin micrófono) termina la llamada sin cerrar la app.
            Log.e(TAG, "Error de audio", e);
            error = true;
            mensajeFinal = "Ha fallado el audio del dispositivo.";
        } finally {
            activa = false;
            cerrarSocket();
            if (hiloMicro != null) {
                try { hiloMicro.join(1000); } catch (InterruptedException ignorada) { }
            }
            if (altavoz != null) {
                try { altavoz.stop(); } catch (RuntimeException ignorada) { }
                altavoz.release();
            }
            if (audio != null) {
                try {
                    audio.setSpeakerphoneOn(altavozAnterior);
                    audio.setMode(modoAnterior);
                } catch (RuntimeException ignorada) { }
            }
            if (colgadaPorMi) {
                avisar(Estado.FINALIZADA, "Has colgado la llamada.");
            } else {
                avisar(error ? Estado.ERROR : Estado.FINALIZADA,
                        mensajeFinal != null ? mensajeFinal : "La llamada ha terminado.");
            }
        }
    }

    @SuppressLint("MissingPermission") // solo se llama si la pantalla ya tiene el permiso RECORD_AUDIO
    private void enviarMicrofono(OutputStream salida) {
        AudioRecord micro = null;
        AcousticEchoCanceler eco = null;
        NoiseSuppressor ruido = null;
        try {
            int minimo = AudioRecord.getMinBufferSize(FRECUENCIA,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            micro = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, FRECUENCIA,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(minimo, BYTES_TRAMA * 4));
            if (micro.getState() != AudioRecord.STATE_INITIALIZED) {
                avisar(Estado.EN_LLAMADA, "No se pudo abrir el micrófono: puedes escuchar, pero no te oirán.");
                return;
            }
            if (AcousticEchoCanceler.isAvailable()) {
                eco = AcousticEchoCanceler.create(micro.getAudioSessionId());
                if (eco != null) eco.setEnabled(true);
            }
            if (NoiseSuppressor.isAvailable()) {
                ruido = NoiseSuppressor.create(micro.getAudioSessionId());
                if (ruido != null) ruido.setEnabled(true);
            }
            micro.startRecording();
            byte[] trama = new byte[BYTES_TRAMA];
            while (activa) {
                int leidos = leerTramaCompleta(micro, trama);
                if (leidos < 0) break;
                salida.write(trama, 0, BYTES_TRAMA);
            }
        } catch (IOException e) {
            // El socket se cerró (alguien colgó): el hilo de red ya informa del motivo.
        } catch (RuntimeException e) {
            Log.e(TAG, "Error del micrófono", e);
            avisar(Estado.EN_LLAMADA, "Ha fallado el micrófono: puedes escuchar, pero no te oirán.");
        } finally {
            if (eco != null) eco.release();
            if (ruido != null) ruido.release();
            if (micro != null) {
                try { micro.stop(); } catch (RuntimeException ignorada) { }
                micro.release();
            }
        }
    }

    /** AudioRecord puede devolver menos bytes de los pedidos; se completa la trama de 20 ms. */
    private int leerTramaCompleta(AudioRecord micro, byte[] trama) {
        int total = 0;
        while (total < trama.length && activa) {
            int n = micro.read(trama, total, trama.length - total);
            if (n < 0) return n;
            total += n;
        }
        return total;
    }

    private AudioTrack crearAltavoz() {
        int minimo = AudioTrack.getMinBufferSize(FRECUENCIA,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        return new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setSampleRate(FRECUENCIA)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setBufferSizeInBytes(Math.max(minimo, BYTES_TRAMA * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
    }

    private void cerrarSocket() {
        Socket s = socket;
        if (s != null) {
            try { s.close(); } catch (IOException ignorada) { }
        }
    }

    private void avisar(Estado nuevo, String mensaje) {
        estado = nuevo;
        principal.post(() -> oyente.alCambiarEstado(nuevo, mensaje));
    }

    // ---------- Partes sin Android, probadas en LlamadaVozTest ----------

    static String crearCabecera(String requestId, String rol, String host) {
        return "POST /audio/" + requestId + "/" + rol + " HTTP/1.1\r\n"
                + "Host: " + host + "\r\n"
                + "Content-Length: 0\r\n"
                + "\r\n";
    }

    /** Lee la respuesta HTTP hasta la línea en blanco y devuelve el código (o -1 si no es válida). */
    static int leerCodigoRespuesta(InputStream entrada) throws IOException {
        StringBuilder cabecera = new StringBuilder();
        while (cabecera.length() < 8192) {
            int c = entrada.read();
            if (c < 0) throw new IOException("Conexión cerrada antes de responder");
            cabecera.append((char) c);
            if (cabecera.length() >= 4
                    && cabecera.substring(cabecera.length() - 4).equals("\r\n\r\n")) {
                break;
            }
        }
        String[] partes = cabecera.toString().split(" ", 3);
        try {
            return partes.length >= 2 ? Integer.parseInt(partes[1].trim()) : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    static String mensajeParaCodigo(int codigo) {
        switch (codigo) {
            case 408: return "La otra persona no se ha conectado a tiempo.";
            case 404:
            case 409: return "Esta petición ya no está disponible para llamar.";
            default:  return "El servidor de llamadas respondió con un error (" + codigo + ").";
        }
    }
}
