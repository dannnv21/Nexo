package com.nexo.app;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/** La URL del servidor es configurable; si viene mal escrita no debe cerrar la app. */
public class ApiClientTest {

    @Test
    public void normalizaLaUrlDelServidor() {
        assertEquals("http://10.0.2.2:3000/", ApiClient.normalizar("http://10.0.2.2:3000/"));
        assertEquals("http://10.0.2.2:3000/", ApiClient.normalizar("http://10.0.2.2:3000"));
        assertEquals("http://192.168.1.20:3000/", ApiClient.normalizar(" 192.168.1.20:3000 "));
        assertEquals("http://10.0.2.2:3000/", ApiClient.normalizar(""));
        assertEquals("http://10.0.2.2:3000/", ApiClient.normalizar(null));
    }
}
