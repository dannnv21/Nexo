package com.nexo.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Partes de LlamadaVoz que no necesitan Android: el "saludo" con el servidor. */
public class LlamadaVozTest {

    private static ByteArrayInputStream flujo(String texto) {
        return new ByteArrayInputStream(texto.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    public void laCabeceraPideLaSalaDeAudioDeLaPeticion() {
        String cabecera = LlamadaVoz.crearCabecera("req_1", LlamadaVoz.ROL_USUARIO, "10.0.2.2");
        assertTrue(cabecera.startsWith("POST /audio/req_1/usuario HTTP/1.1\r\n"));
        assertTrue(cabecera.endsWith("\r\n\r\n"));
    }

    @Test
    public void leeElCodigoYDejaElAudioSinConsumir() throws IOException {
        ByteArrayInputStream entrada = flujo(
                "HTTP/1.0 200 OK\r\nContent-Type: application/octet-stream\r\n\r\nAUDIO");
        assertEquals(200, LlamadaVoz.leerCodigoRespuesta(entrada));
        assertEquals('A', entrada.read()); // lo siguiente ya es audio
    }

    @Test
    public void reconoceErrores() throws IOException {
        assertEquals(408, LlamadaVoz.leerCodigoRespuesta(flujo("HTTP/1.0 408 Timeout\r\n\r\n")));
        assertEquals(-1, LlamadaVoz.leerCodigoRespuesta(flujo("basura\r\n\r\n")));
        try {
            LlamadaVoz.leerCodigoRespuesta(flujo("HTTP/1.0 20"));
            fail("Debe fallar si el servidor corta la conexión");
        } catch (IOException esperado) {
            // correcto
        }
    }

    @Test
    public void lasTramasSonDe20msYPares() {
        assertEquals(640, LlamadaVoz.BYTES_TRAMA);
        assertEquals(0, LlamadaVoz.MAX_RETRASO_BYTES % 2);
    }
}
