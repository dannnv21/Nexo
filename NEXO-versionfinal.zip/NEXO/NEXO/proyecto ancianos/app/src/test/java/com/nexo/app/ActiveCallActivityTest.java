package com.nexo.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import android.Manifest;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.test.core.app.ApplicationProvider;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.Shadows;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

/**
 * Pruebas de RF-07: llamada de voz entre voluntario y usuario tras la aceptación.
 * Se usa una llamada falsa para no abrir red ni audio reales.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class ActiveCallActivityTest {

    private static final String NUMERO = "+34600111222";

    /** Llamada falsa: guarda con qué datos se creó y si se inició o colgó. */
    static class LlamadaFalsa extends LlamadaVoz {
        final String requestId;
        final String rol;
        boolean iniciada;
        boolean conMicro;
        boolean colgada;

        LlamadaFalsa(Context c, String requestId, String rol, Oyente o) {
            super(c, requestId, rol, o);
            this.requestId = requestId;
            this.rol = rol;
        }

        @Override public synchronized void iniciar(boolean conMicrofono) {
            iniciada = true;
            conMicro = conMicrofono;
        }

        @Override public void colgar() { colgada = true; }

        @Override public boolean estaActiva() { return iniciada && !colgada; }
    }

    private LlamadaFalsa ultima;
    private ActivityController<ActiveCallActivity> controlador;

    @Before
    public void instalarLlamadaFalsa() {
        ultima = null;
        ActiveCallActivity.fabrica = (c, id, rol, o) -> ultima = new LlamadaFalsa(c, id, rol, o);
        Application app = ApplicationProvider.getApplicationContext();
        Shadows.shadowOf(app).grantPermissions(Manifest.permission.RECORD_AUDIO);
    }

    @After
    public void restaurar() {
        ActiveCallActivity.fabrica = LlamadaVoz::new;
    }

    private ActiveCallActivity crear(boolean ladoUsuario, String telefono) {
        Intent intent = new Intent(ApplicationProvider.getApplicationContext(),
                ActiveCallActivity.class);
        intent.putExtra(ActiveCallActivity.EXTRA_REQUEST_ID, "req_prueba");
        intent.putExtra(ActiveCallActivity.EXTRA_TOPIC, "Mis plantas");
        intent.putExtra(ActiveCallActivity.EXTRA_USER_SIDE, ladoUsuario);
        if (telefono != null) {
            intent.putExtra(ActiveCallActivity.EXTRA_USER_PHONE, telefono);
        }
        controlador = Robolectric.buildActivity(ActiveCallActivity.class, intent).setup();
        return controlador.get();
    }

    private String estado(ActiveCallActivity a) {
        return ((TextView) a.findViewById(R.id.textoEstadoLlamada)).getText().toString();
    }

    @Test
    public void usuario_entraSoloEnLaLlamadaComoUsuario() {
        crear(true, null);
        assertNotNull(ultima);
        assertTrue(ultima.iniciada);
        assertTrue(ultima.conMicro);
        assertEquals("req_prueba", ultima.requestId);
        assertEquals(LlamadaVoz.ROL_USUARIO, ultima.rol);
    }

    @Test
    public void voluntario_entraSoloEnLaLlamadaComoVoluntario() {
        crear(false, NUMERO);
        assertTrue(ultima.iniciada);
        assertEquals(LlamadaVoz.ROL_VOLUNTARIO, ultima.rol);
    }

    @Test
    public void laPantallaMuestraLosEstadosDeLaLlamada() {
        ActiveCallActivity a = crear(true, null);

        a.alCambiarEstado(LlamadaVoz.Estado.CONECTANDO, null);
        assertTrue(estado(a).startsWith("Conectando"));

        a.alCambiarEstado(LlamadaVoz.Estado.EN_LLAMADA, null);
        assertEquals("En llamada", estado(a));

        a.alCambiarEstado(LlamadaVoz.Estado.FINALIZADA, "La otra persona ha colgado.");
        assertEquals("La otra persona ha colgado.", estado(a));
        assertEquals(View.VISIBLE, a.findViewById(R.id.botonReintentar).getVisibility());
    }

    @Test
    public void usuario_alPulsarColgar_seCuelgaYPasaALaValoracion() {
        ActiveCallActivity a = crear(true, null);

        ((Button) a.findViewById(R.id.botonColgar)).performClick();

        assertTrue(ultima.colgada);
        assertTrue(a.isFinishing());
        Intent siguiente = Shadows.shadowOf(a).getNextStartedActivity();
        assertEquals(RatingActivity.class.getName(), siguiente.getComponent().getClassName());
    }

    @Test
    public void voluntario_alPulsarColgar_vuelveAlInicio() {
        ActiveCallActivity a = crear(false, NUMERO);

        ((Button) a.findViewById(R.id.botonColgar)).performClick();

        assertTrue(ultima.colgada);
        Intent siguiente = Shadows.shadowOf(a).getNextStartedActivity();
        assertEquals(WelcomeActivity.class.getName(), siguiente.getComponent().getClassName());
    }

    @Test
    public void alCerrarLaPantalla_seCuelga() {
        crear(false, NUMERO);
        controlador.pause().stop().destroy();
        assertTrue(ultima.colgada);
    }

    @Test
    public void sinPermisoDeMicro_loPideAntesDeLlamar() {
        Application app = ApplicationProvider.getApplicationContext();
        Shadows.shadowOf(app).denyPermissions(Manifest.permission.RECORD_AUDIO);

        ActiveCallActivity a = crear(true, null);

        assertNull(ultima); // todavía no se ha llamado: se está preguntando
        assertNotNull(Shadows.shadowOf(a).getLastRequestedPermission());
        a.onRequestPermissionsResult(41, new String[]{Manifest.permission.RECORD_AUDIO},
                new int[]{android.content.pm.PackageManager.PERMISSION_DENIED});
        assertTrue(ultima.iniciada);   // sin permiso entra igualmente, solo para escuchar
        assertFalse(ultima.conMicro);
    }

    @Test
    public void voluntario_puedeLlamarTambienPorTelefono() {
        ActiveCallActivity actividad = crear(false, NUMERO);
        Button llamar = actividad.findViewById(R.id.botonLlamar);
        assertNotNull(llamar);

        llamar.performClick();

        Intent siguiente = Shadows.shadowOf(actividad).getNextStartedActivity();
        assertNotNull(siguiente);
        assertEquals(Intent.ACTION_DIAL, siguiente.getAction());
        assertEquals(NUMERO, siguiente.getData().getSchemeSpecificPart());
    }

    @Test
    public void usuario_noTieneBotonDeTelefono() {
        assertNull(crear(true, null).findViewById(R.id.botonLlamar));
    }

    @Test
    public void validacionDelTelefono() {
        assertTrue(ActiveCallActivity.esTelefonoValido("+34600111222"));
        assertTrue(ActiveCallActivity.esTelefonoValido("600 111 222"));
        assertFalse(ActiveCallActivity.esTelefonoValido(null));
        assertFalse(ActiveCallActivity.esTelefonoValido(""));
        assertFalse(ActiveCallActivity.esTelefonoValido("abc"));
    }
}
