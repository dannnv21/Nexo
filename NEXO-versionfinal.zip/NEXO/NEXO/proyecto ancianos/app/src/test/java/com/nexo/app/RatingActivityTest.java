package com.nexo.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;

/** Pruebas de la pantalla de valoración tras la llamada y del mensaje de agradecimiento. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class RatingActivityTest {

    private RatingActivity crear() {
        return Robolectric.buildActivity(RatingActivity.class).setup().get();
    }

    @Test
    public void alEmpezar_elBotonEstaBloqueadoYNoHayGracias() {
        RatingActivity a = crear();

        assertFalse(a.findViewById(R.id.botonEnviarValoracion).isEnabled());
        assertEquals(View.VISIBLE, a.findViewById(R.id.grupoValoracion).getVisibility());
        assertEquals(View.GONE, a.findViewById(R.id.grupoGracias).getVisibility());
    }

    @Test
    public void alElegirUnaCara_seMarcaYSeActivaElBoton() {
        RatingActivity a = crear();

        a.findViewById(R.id.opcionBien).performClick();

        assertTrue(a.findViewById(R.id.opcionBien).isSelected());
        assertFalse(a.findViewById(R.id.opcionMal).isSelected());
        assertTrue(a.findViewById(R.id.botonEnviarValoracion).isEnabled());

        a.findViewById(R.id.opcionRegular).performClick();
        assertTrue(a.findViewById(R.id.opcionRegular).isSelected());
        assertFalse(a.findViewById(R.id.opcionBien).isSelected());
    }

    @Test
    public void alEnviar_apareceElAgradecimiento() {
        RatingActivity a = crear();
        a.findViewById(R.id.opcionMal).performClick();

        ((Button) a.findViewById(R.id.botonEnviarValoracion)).performClick();

        assertEquals(View.GONE, a.findViewById(R.id.grupoValoracion).getVisibility());
        assertEquals(View.VISIBLE, a.findViewById(R.id.grupoGracias).getVisibility());
    }

    @Test
    public void volverAlInicio_navegaALaBienvenida() {
        RatingActivity a = crear();

        a.findViewById(R.id.botonSaltarValoracion).performClick();

        Intent siguiente = Shadows.shadowOf(a).getNextStartedActivity();
        assertNotNull(siguiente);
        assertEquals(WelcomeActivity.class.getName(), siguiente.getComponent().getClassName());
        assertTrue(a.isFinishing());
    }
}
