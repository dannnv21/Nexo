"""Pruebas del flujo de llamada en el servidor (python -m unittest test_server.py)."""
import json
import socket
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

import server


class FlujoLlamadaTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), server.Manejador)
        cls.url = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        server.peticiones.clear()

    def llamar(self, metodo, ruta, cuerpo=None):
        datos = json.dumps(cuerpo).encode() if cuerpo is not None else None
        req = urllib.request.Request(self.url + ruta, data=datos, method=metodo)
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def crear(self, rid="req_1", tema="Mis plantas 🌱"):
        return self.llamar("POST", "/requests", {"request_id": rid, "topic": tema,
                                                 "user_phone": "+34600111222",
                                                 "timeout_seconds": 120})

    def test_usuario_pide_y_voluntario_acepta(self):
        self.assertEqual(self.crear()[0], 201)
        _, lista = self.llamar("GET", "/requests?status=searching")
        self.assertEqual([p["request_id"] for p in lista], ["req_1"])

        codigo, p = self.llamar("POST", "/requests/req_1/accept", {"volunteer_id": "vol_a"})
        self.assertEqual(codigo, 200)
        self.assertEqual(p["user_phone"], "+34600111222")  # el voluntario recibe el número

        _, p = self.llamar("GET", "/requests/req_1")  # lo que sondea la pantalla de espera
        self.assertEqual((p["status"], p["volunteer_id"]), ("accepted", "vol_a"))
        self.assertEqual(self.llamar("GET", "/requests?status=searching")[1], [])

    def test_dos_voluntarios_no_pueden_aceptar_la_misma(self):
        self.crear()
        self.assertEqual(self.llamar("POST", "/requests/req_1/accept", {"volunteer_id": "a"})[0], 200)
        self.assertEqual(self.llamar("POST", "/requests/req_1/accept", {"volunteer_id": "b"})[0], 409)

    def test_cancelada_no_se_puede_aceptar(self):
        self.crear()
        self.assertEqual(self.llamar("POST", "/requests/req_1/cancel", {})[0], 200)
        self.assertEqual(self.llamar("POST", "/requests/req_1/accept", {"volunteer_id": "a"})[0], 409)

    def test_reenvio_es_idempotente(self):
        self.assertEqual(self.crear()[0], 201)
        self.assertEqual(self.crear()[0], 200)
        self.assertEqual(len(server.peticiones), 1)

    def test_errores_de_entrada(self):
        self.assertEqual(self.crear(tema="   ")[0], 400)
        self.crear()
        self.assertEqual(self.llamar("POST", "/requests/req_1/accept", {})[0], 400)
        self.assertEqual(self.llamar("GET", "/requests/no_existe")[0], 404)


    # ---------- Llamada de voz ----------

    def conectar_audio(self, rid, rol):
        """Hace lo mismo que LlamadaVoz.java: abre un socket y pide POST /audio/<id>/<rol>."""
        s = socket.create_connection(("127.0.0.1", self.srv.server_address[1]), timeout=5)
        s.sendall(f"POST /audio/{rid}/{rol} HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\n\r\n".encode())
        return s

    def leer_cabecera(self, s):
        datos = b""
        while b"\r\n\r\n" not in datos:
            trozo = s.recv(1)
            if not trozo:
                break
            datos += trozo
        return int(datos.split(b" ")[1])

    def recibir(self, s, n):
        datos = b""
        while len(datos) < n:
            trozo = s.recv(n - len(datos))
            if not trozo:
                break
            datos += trozo
        return datos

    def aceptada(self, rid="req_1"):
        self.crear(rid)
        self.llamar("POST", f"/requests/{rid}/accept", {"volunteer_id": "vol_a"})

    def test_llamada_de_voz_entre_usuario_y_voluntario(self):
        self.aceptada()
        usuario = self.conectar_audio("req_1", "usuario")
        time.sleep(0.2)                       # el usuario entra primero y espera
        voluntario = self.conectar_audio("req_1", "voluntario")
        self.assertEqual(self.leer_cabecera(usuario), 200)
        self.assertEqual(self.leer_cabecera(voluntario), 200)

        voz_usuario = bytes(range(256)) * 25          # 6400 bytes = 0,2 s de audio
        voz_voluntario = bytes(reversed(range(256))) * 25
        usuario.sendall(voz_usuario)
        voluntario.sendall(voz_voluntario)
        self.assertEqual(self.recibir(voluntario, len(voz_usuario)), voz_usuario)
        self.assertEqual(self.recibir(usuario, len(voz_voluntario)), voz_voluntario)

        usuario.close()                                # cuelga el usuario...
        self.assertEqual(voluntario.recv(10), b"")     # ...y al voluntario se le corta
        voluntario.close()
        time.sleep(0.2)
        self.assertEqual(server.salas, {})

    def test_llamada_solo_si_la_peticion_esta_aceptada(self):
        self.crear()
        s = self.conectar_audio("req_1", "usuario")
        self.assertEqual(self.leer_cabecera(s), 409)
        s.close()
        s = self.conectar_audio("no_existe", "usuario")
        self.assertEqual(self.leer_cabecera(s), 404)
        s.close()
        s = self.conectar_audio("req_1", "intruso")
        self.assertEqual(self.leer_cabecera(s), 400)
        s.close()

    def test_si_la_otra_persona_no_llega_se_responde_408(self):
        self.aceptada()
        anterior, server.ESPERA_PAREJA_S = server.ESPERA_PAREJA_S, 0.5
        try:
            s = self.conectar_audio("req_1", "voluntario")
            self.assertEqual(self.leer_cabecera(s), 408)
            s.close()
            self.assertEqual(server.salas, {})
        finally:
            server.ESPERA_PAREJA_S = anterior


if __name__ == "__main__":
    unittest.main()
