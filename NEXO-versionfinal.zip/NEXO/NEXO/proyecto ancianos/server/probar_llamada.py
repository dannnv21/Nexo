"""Simula la otra parte de la llamada para probar la app con UN solo emulador.

Uso (con server.py ya en marcha en otra terminal):

  python probar_llamada.py voluntario
      Espera a que alguien pida hablar desde la app (Quiero hablar -> Enviar),
      acepta la petición como si fuera un voluntario y ENTRA EN LA LLAMADA DE VOZ.

  python probar_llamada.py usuario "Mis plantas"
      Crea una petición como si fuera una persona mayor. En la app entra en
      "Soy voluntario" -> "Aceptar llamada" y el script entra en la llamada de voz.

  En la llamada, el script hace de la otra persona: te devuelve lo que dices
  (eco, ~0,5 s después) y emite un pitido cada 3 segundos. Si oyes el pitido,
  el audio del servidor al móvil funciona; si oyes tu eco, también el micrófono.
  Ctrl+C para colgar.

  python probar_llamada.py estado
      Lista todas las peticiones del servidor.

Opcional: --url http://localhost:3001  (si arrancaste el servidor en otro puerto)
"""
import json
import math
import socket
import struct
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

URL = "http://localhost:3000"


def peticion(metodo, ruta, cuerpo=None):
    datos = json.dumps(cuerpo).encode("utf-8") if cuerpo is not None else None
    req = urllib.request.Request(URL + ruta, data=datos, method=metodo,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8") or "{}")


FRECUENCIA = 16000
TRAMA = FRECUENCIA * 2 // 50          # 20 ms de audio PCM 16 bits mono = 640 bytes
PITIDO = b"".join(struct.pack("<h", int(6000 * math.sin(2 * math.pi * 660 * i / FRECUENCIA)))
                  for i in range(FRECUENCIA // 4))   # 0,25 s a 660 Hz


def llamada_de_voz(rid, rol):
    """Entra en la llamada como 'rol', devuelve el eco de lo recibido y mete un pitido cada 3 s."""
    url = urllib.parse.urlparse(URL)
    print(f"Entrando en la llamada de voz como {rol}... (la app tiene que estar en la pantalla de llamada)")
    s = socket.create_connection((url.hostname, url.port or 80), timeout=100)
    s.sendall(f"POST /audio/{rid}/{rol} HTTP/1.1\r\nHost: {url.hostname}\r\nContent-Length: 0\r\n\r\n".encode())
    cabecera = b""
    while b"\r\n\r\n" not in cabecera:
        trozo = s.recv(1)
        if not trozo:
            break
        cabecera += trozo
    codigo = cabecera.split(b" ")[1].decode() if b" " in cabecera else "?"
    if codigo != "200":
        print("El servidor no ha conectado la llamada:", cabecera.decode(errors="replace").splitlines()[:1])
        return 1
    s.settimeout(None)
    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    print("EN LLAMADA. Habla en el emulador: oirás tu eco y un pitido cada 3 s. Ctrl+C para colgar.")

    recibido = bytearray()
    cerrojo_audio = threading.Lock()
    viva = [True]
    bytes_recibidos = [0]

    def recibir():
        try:
            while viva[0]:
                datos = s.recv(4096)
                if not datos:
                    break
                bytes_recibidos[0] += len(datos)
                with cerrojo_audio:
                    recibido.extend(datos)
                    del recibido[:-FRECUENCIA * 2]   # como mucho 1 s guardado
        except OSError:
            pass
        viva[0] = False

    threading.Thread(target=recibir, daemon=True).start()
    inicio = time.time()
    n = 0
    retraso_eco = FRECUENCIA * 2 // 2          # 0,5 s
    try:
        while viva[0]:
            t = (n * TRAMA) % (FRECUENCIA * 2 * 3)       # posición dentro del ciclo de 3 s
            if t < len(PITIDO):
                trama = PITIDO[t:t + TRAMA].ljust(TRAMA, b"\0")
            else:
                with cerrojo_audio:
                    if len(recibido) >= retraso_eco + TRAMA:
                        trama = bytes(recibido[:TRAMA])
                        del recibido[:TRAMA]
                    else:
                        trama = bytes(TRAMA)              # silencio
            s.sendall(trama)
            n += 1
            espera = inicio + n * 0.02 - time.time()
            if espera > 0:
                time.sleep(espera)
            if n % 250 == 0:
                print(f"  ... {n // 50} s en llamada, recibidos {bytes_recibidos[0] // 1000} KB de audio del móvil")
    except (OSError, KeyboardInterrupt):
        pass
    viva[0] = False
    s.close()
    print("Llamada terminada.")
    return 0


def como_voluntario():
    print("Esperando peticiones... (en la app: Quiero hablar -> escribe un tema -> Enviar)")
    while True:
        _, lista = peticion("GET", "/requests?status=searching")
        if lista:
            p = lista[0]
            codigo, r = peticion("POST", f"/requests/{p['request_id']}/accept",
                                 {"volunteer_id": "voluntario_simulado"})
            if codigo == 200:
                print(f"ACEPTADA '{r['topic']}' ({r['request_id']}).")
                return llamada_de_voz(r["request_id"], "voluntario")
            print("No se pudo aceptar:", codigo, r)
        time.sleep(1)


def como_usuario(tema):
    rid = "req_" + uuid.uuid4().hex[:12]
    codigo, r = peticion("POST", "/requests", {
        "request_id": rid, "user_phone": "+34600111222", "topic": tema,
        "status": "searching", "timeout_seconds": 120,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    print("Petición creada:", codigo, rid, "-", tema)
    print("Abre 'Soy voluntario' en la app y acéptala (tienes 120 s)...")
    fin = time.time() + 130
    while time.time() < fin:
        _, r = peticion("GET", f"/requests/{rid}")
        if r.get("status") == "accepted":
            print("Aceptada por", r.get("volunteer_id"))
            return llamada_de_voz(rid, "usuario")
        if r.get("status") != "searching":
            print("Estado final:", r.get("status"))
            return 1
        time.sleep(1)
    print("Nadie la aceptó a tiempo.")
    return 1


def main(args):
    global URL
    if "--url" in args:
        i = args.index("--url")
        URL = args[i + 1].rstrip("/")
        args = args[:i] + args[i + 2:]
    try:
        if args[:1] == ["voluntario"]:
            return como_voluntario()
        if args[:1] == ["usuario"]:
            return como_usuario(" ".join(args[1:]) or "Mi día")
        if args[:1] == ["estado"]:
            print(json.dumps(peticion("GET", "/requests")[1], ensure_ascii=False, indent=2))
            return 0
    except urllib.error.URLError:
        print(f"No hay servidor en {URL}. Arráncalo antes con: python server.py")
        return 1
    except KeyboardInterrupt:
        return 0
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
