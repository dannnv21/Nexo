"""Servidor local de pruebas para NEXO (sin dependencias, solo Python 3).

Uso:   python server.py            (escucha en el puerto 3000 de todas las interfaces)
       python server.py 3001       (otro puerto, si el 3000 está ocupado en tu portátil)
Desde el emulador Android, este PC es http://10.0.2.2:3000/
Con un móvil físico usa la IP que se muestra al arrancar (misma red Wi-Fi).

Endpoints:
  POST /requests                  crea la petición (idempotente por request_id)
  GET  /requests?status=searching lista peticiones (el filtro es opcional)
  GET  /requests/<id>             estado de una petición
  POST /requests/<id>/accept      {"volunteer_id": "..."}  -> 409 si ya no está disponible
  POST /requests/<id>/cancel      -> 409 si ya fue aceptada
  POST /audio/<id>/<rol>          LLAMADA DE VOZ. rol = usuario | voluntario. Solo si la
                                  petición está "accepted". El servidor espera a que entre la
                                  otra persona (hasta 90 s), responde 200 y a partir de ahí la
                                  conexión deja de ser HTTP: se reenvía el audio en bruto
                                  (PCM 16 bits, 16 kHz, mono) de un móvil al otro.
                                  408 si la otra persona no llega a tiempo.
"""
import json
import os
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

# En la consola de Windows (cp1252) un emoji o ciertos caracteres en el tema hacían fallar print().
for _flujo in (sys.stdout, sys.stderr):
    try:
        _flujo.reconfigure(errors="replace", line_buffering=True)
    except (AttributeError, ValueError):
        pass

PUERTO = int(os.environ.get("HABLAMOS_PORT", "3000"))
MARGEN_EXPIRACION_S = 10  # margen extra sobre timeout_seconds antes de descartar una petición huérfana

peticiones = {}   # request_id -> dict
cerrojo = threading.Lock()

# ---------- Llamadas de voz ----------
ROLES = ("usuario", "voluntario")
ESPERA_PAREJA_S = 90      # cuánto espera uno a que entre el otro en la llamada
salas = {}                # request_id -> {rol: Participante}
cerrojo_salas = threading.Condition()


class Participante:
    def __init__(self, sock):
        self.sock = sock
        self.listo = threading.Event()   # ya se le envió el 200: se le puede mandar audio


def cerrar_socket(sock):
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except OSError:
        pass


def expirar_antiguas():
    """Cancela peticiones 'searching' que nadie ha cancelado (p. ej. la app se cerró de golpe)."""
    ahora = time.time()
    for p in peticiones.values():
        if p["status"] == "searching" and ahora - p["_recibida"] > p["timeout_seconds"] + MARGEN_EXPIRACION_S:
            p["status"] = "cancelled"


def publica(p):
    return {k: v for k, v in p.items() if not k.startswith("_")}


class Manejador(BaseHTTPRequestHandler):
    def _responder(self, codigo, cuerpo=None):
        datos = json.dumps(cuerpo if cuerpo is not None else {}, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(datos)))
        self.end_headers()
        self.wfile.write(datos)

    def _leer_json(self):
        largo = int(self.headers.get("Content-Length") or 0)
        if largo == 0:
            return {}
        try:
            return json.loads(self.rfile.read(largo).decode("utf-8"))
        except ValueError:
            return None

    def do_GET(self):
        url = urlparse(self.path)
        partes = [x for x in url.path.split("/") if x]
        with cerrojo:
            expirar_antiguas()
            if partes == ["requests"]:
                estado = parse_qs(url.query).get("status", [None])[0]
                lista = [publica(p) for p in peticiones.values()
                         if estado is None or p["status"] == estado]
                return self._responder(200, lista)
            if len(partes) == 2 and partes[0] == "requests":
                p = peticiones.get(partes[1])
                if p is None:
                    return self._responder(404, {"error": "no existe"})
                return self._responder(200, publica(p))
        self._responder(404, {"error": "ruta desconocida"})

    def _llamada_voz(self, rid, rol):
        """Empareja a usuario y voluntario de una petición aceptada y reenvía su audio."""
        with cerrojo:
            p = peticiones.get(rid)
            if p is None:
                return self._responder(404, {"error": "no existe"})
            if p["status"] != "accepted":
                return self._responder(409, {"error": "la petición no está aceptada"})
        otro_rol = ROLES[1] if rol == ROLES[0] else ROLES[0]
        sock = self.connection
        sock.settimeout(None)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        yo = Participante(sock)

        with cerrojo_salas:
            sala = salas.setdefault(rid, {})
            anterior = sala.get(rol)
            if anterior is not None:          # reconexión: se sustituye la conexión vieja
                cerrar_socket(anterior.sock)
            sala[rol] = yo
            cerrojo_salas.notify_all()
            limite = time.time() + ESPERA_PAREJA_S
            while sala.get(otro_rol) is None and sala.get(rol) is yo:
                restante = limite - time.time()
                if restante <= 0:
                    break
                cerrojo_salas.wait(restante)
            pareja = sala.get(otro_rol)
            if pareja is None or sala.get(rol) is not yo:
                if sala.get(rol) is yo:
                    del sala[rol]
                if not sala:
                    salas.pop(rid, None)
                pareja = None
        if pareja is None:
            self.close_connection = True
            return self._responder(408, {"error": "la otra persona no se ha conectado"})

        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.flush()
        yo.listo.set()
        if rol == "usuario":
            print("LLAMADA ", rid, "conectada")
        try:
            # No se reenvía nada hasta que la pareja haya recibido su 200.
            if pareja.listo.wait(15):
                while True:
                    datos = self.rfile.read1(4096)
                    if not datos:
                        break
                    pareja.sock.sendall(datos)
        except OSError:
            pass
        finally:
            with cerrojo_salas:
                sala = salas.get(rid, {})
                if sala.get(rol) is yo:
                    del sala[rol]
                if not sala:
                    salas.pop(rid, None)
            cerrar_socket(pareja.sock)      # al colgar uno, se corta también al otro
            if rol == "usuario":
                print("COLGADA ", rid)

    def do_POST(self):
        partes = [x for x in urlparse(self.path).path.split("/") if x]
        if len(partes) == 3 and partes[0] == "audio":
            if partes[2] not in ROLES:
                return self._responder(400, {"error": "rol debe ser usuario o voluntario"})
            return self._llamada_voz(partes[1], partes[2])
        cuerpo = self._leer_json()
        if cuerpo is None:
            return self._responder(400, {"error": "JSON no válido"})
        with cerrojo:
            expirar_antiguas()
            if partes == ["requests"]:
                rid = cuerpo.get("request_id")
                if not rid or not str(cuerpo.get("topic", "")).strip():
                    return self._responder(400, {"error": "faltan request_id o topic"})
                if rid in peticiones:  # reintento del cliente: no se duplica
                    return self._responder(200, publica(peticiones[rid]))
                p = {
                    "request_id": rid,
                    "user_phone": cuerpo.get("user_phone"),
                    "topic": str(cuerpo["topic"]).strip()[:100],
                    "status": "searching",
                    "created_at": cuerpo.get("created_at"),
                    "timeout_seconds": int(cuerpo.get("timeout_seconds") or 120),
                    "volunteer_id": None,
                    "_recibida": time.time(),
                }
                peticiones[rid] = p
                print("NUEVA   ", rid, "-", p["topic"])
                return self._responder(201, publica(p))

            if len(partes) == 3 and partes[0] == "requests":
                p = peticiones.get(partes[1])
                if p is None:
                    return self._responder(404, {"error": "no existe"})
                if p["status"] != "searching":
                    return self._responder(409, {"error": "ya está " + p["status"]})
                if partes[2] == "accept":
                    if not cuerpo.get("volunteer_id"):
                        return self._responder(400, {"error": "falta volunteer_id"})
                    p["status"] = "accepted"
                    p["volunteer_id"] = cuerpo["volunteer_id"]
                    print("ACEPTADA", p["request_id"], "por", p["volunteer_id"])
                    return self._responder(200, publica(p))
                if partes[2] == "cancel":
                    p["status"] = "cancelled"
                    print("CANCELADA", p["request_id"])
                    return self._responder(200, publica(p))
        self._responder(404, {"error": "ruta desconocida"})

    def log_message(self, formato, *args):
        pass  # silencia el log por petición (el sondeo genera muchas)


def ip_local():
    """IP de este PC en la red local (para probar con un móvil físico). No envía datos."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            PUERTO = int(sys.argv[1])
        except ValueError:
            print("El puerto debe ser un número, p. ej.: python server.py 3001")
            sys.exit(1)
    try:
        servidor = ThreadingHTTPServer(("0.0.0.0", PUERTO), Manejador)
    except OSError as e:
        print(f"No se pudo abrir el puerto {PUERTO} ({e}). Prueba con otro: python server.py 3001")
        sys.exit(1)
    print(f"Servidor en marcha en el puerto {PUERTO}")
    print(f"  - Emulador de Android Studio:  http://10.0.2.2:{PUERTO}/")
    print(f"  - Móvil físico (misma Wi-Fi):  http://{ip_local()}:{PUERTO}/")
    print(f"  - Navegador de este PC:        http://localhost:{PUERTO}/requests")
    print("Pulsa Ctrl+C para pararlo.")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
