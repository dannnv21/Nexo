# Cómo ejecutar NEXO en cualquier portátil

## 1. Abrir el proyecto
1. Android Studio → **File → Open** → elige la carpeta `proyecto ancianos` (la que contiene `settings.gradle`).
2. Si pregunta por el SDK, acepta: crea él solo `local.properties` con la ruta de **tu** SDK.
3. Si falla la sincronización con un error de Java/JDK: **Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK** → elige **jbr-21** o **17** (Gradle 8.5 no funciona con JDK 22 o superior).
4. Si Android Studio ofrece actualizar el "Android Gradle Plugin", puedes decir que no: no hace falta.

## 2. Arrancar el servidor (obligatorio)
En una terminal, dentro de `server/`:
```
python server.py          (en Mac/Linux puede ser python3)
```
Déjalo abierto. Si el puerto 3000 está ocupado: `python server.py 3001` y añade a `local.properties`:
`hablamos.serverUrl=http://10.0.2.2:3001/`

## 3. Probar la llamada de voz voluntario ↔ usuario
Cuando el voluntario acepta, **los dos móviles entran solos en una llamada de voz** dentro de la app
(la primera vez Android pide permiso de micrófono: pulsa *Permitir*). Botón rojo grande: *Colgar*.

**Activa el micrófono del emulador** (se desactiva cada vez que lo reinicias): en la barra del
emulador, `⋯` (Extended controls) → **Microphone** → activa **"Virtual microphone uses host audio input"**.
Sin esto la llamada conecta igual, pero el otro lado solo oye silencio.

**Opción A – un emulador + script (recomendada para empezar)**
- Usuario en la app: *Quiero hablar → tema → Enviar*. En otra terminal: `python probar_llamada.py voluntario`.
- Voluntario en la app: `python probar_llamada.py usuario "Mis plantas"` → en la app *Soy voluntario → Aceptar llamada*.
- En ambos casos el script hace de la otra persona: oirás **un pitido cada 3 s** (el audio llega al móvil) y
  **tu propia voz con eco** medio segundo después (tu micrófono llega al otro lado). Ctrl+C en el script = cuelga.

**Opción B – dos emuladores**
Device Manager → 2 dispositivos *Phone* → arráncalos → en el desplegable de dispositivos
*Select Multiple Devices* → marca ambos → Run. Uno pide hablar, el otro acepta como voluntario.
Como los dos usan el micro y los altavoces del mismo portátil, **usa auriculares** (o activa el micro
del host solo en uno) para evitar pitidos de acople.

**Opción C – dos móviles reales (la mejor prueba)**: ver punto 4, con los dos móviles en la misma Wi-Fi que el portátil.

No pulses Atrás en la pantalla de espera: eso cancela la petición (RF-05). En la llamada, salir de la
pantalla cuelga. Si la app pasa a segundo plano, Android silencia el micrófono (el otro deja de oírte).

## 4. Móvil físico (opcional)
Mismo Wi-Fi que el portátil. En `local.properties` añade la IP que muestra `server.py` al arrancar:
`hablamos.serverUrl=http://192.168.X.X:3000/` → *Sync Project* → Run. Si no conecta, permite Python en el firewall.

## 5. Pruebas automáticas
- App: `./gradlew test` (Windows: `gradlew.bat test`) o clic derecho en `app/src/test` → *Run Tests*.
- Servidor: dentro de `server/`, `python -m unittest test_server.py`.
