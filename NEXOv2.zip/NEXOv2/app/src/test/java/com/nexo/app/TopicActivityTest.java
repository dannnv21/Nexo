package com.nexo.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;

/**
 * Pruebas de la T2 y la T3: Frame 2 (tema de conversación).
 * Requisitos cubiertos: RF-02, RF-03, RF-04, RF-05, LC-01 y LC-02.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class TopicActivityTest {

    private boolean hayRed;

    @Before
    public void instalarServicioFalso() {
        hayRed = true;
        CallService.establecerParaPruebas(new CallService(() -> hayRed, "+34600111222"));
    }

    @After
    public void limpiarServicio() {
        CallService.establecerParaPruebas(null);
    }

    private TopicActivity crearActividad() {
        return Robolectric.buildActivity(TopicActivity.class).setup().get();
    }

    @Test
    public void muestraCampoDeTextoYBotonEnviar() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);

        assertEquals(View.VISIBLE, campo.getVisibility());
        assertEquals(View.VISIBLE, boton.getVisibility());
        assertEquals("Enviar", boton.getText().toString());
    }

    @Test
    public void botonEmpiezaDeshabilitado() {
        Button boton = crearActividad().findViewById(R.id.botonEnviar);
        assertFalse(boton.isEnabled());
    }

    @Test
    public void conSoloEspacios_elBotonSigueDeshabilitado() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);

        campo.setText("     ");

        assertFalse(boton.isEnabled());
    }

    @Test
    public void conTextoValido_elBotonSeHabilita() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);

        campo.setText("Mis plantas");

        assertTrue(boton.isEnabled());
    }

    @Test
    public void siSeBorraElTexto_elBotonSeVuelveADeshabilitar() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);

        campo.setText("Mi día");
        campo.setText("");

        assertFalse(boton.isEnabled());
    }

    @Test
    public void elCampoLimitaElTextoACienCaracteres() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);

        campo.setText("a".repeat(150));

        assertEquals(100, campo.getText().length());
    }

    @Test
    public void elContadorMuestraLosCaracteresEscritos() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        TextView contador = actividad.findViewById(R.id.contadorCaracteres);

        campo.setText("Hola");

        assertEquals("4/100", contador.getText().toString());
    }

    @Test
    public void alPulsarEnviar_seBloqueaElBotonYElCampo() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);
        campo.setText("Mis plantas");

        boton.performClick();

        assertFalse(boton.isEnabled());
        assertFalse(campo.isEnabled());
        assertEquals(View.VISIBLE, actividad.findViewById(R.id.textoEnviando).getVisibility());
    }

    @Test
    public void trasEnviar_noSeVuelveAHabilitarAunqueCambieElTexto() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);
        campo.setText("Mis plantas");
        boton.performClick();

        campo.setText("Otro tema");

        assertFalse(boton.isEnabled());
    }

    @Test
    public void validacionDelTema() {
        assertFalse(TopicActivity.esTemaValido(null));
        assertFalse(TopicActivity.esTemaValido(""));
        assertFalse(TopicActivity.esTemaValido("   "));
        assertTrue(TopicActivity.esTemaValido("Mi día"));
        assertTrue(TopicActivity.esTemaValido("a".repeat(100)));
        assertFalse(TopicActivity.esTemaValido("a".repeat(101)));
    }

    // ---------- T3: navegación al Frame 3 y errores de red ----------

    @Test
    public void alEnviarConRed_navegaALaPantallaDeEspera() {
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        campo.setText("Mis plantas");

        ((Button) actividad.findViewById(R.id.botonEnviar)).performClick();

        Intent siguiente = Shadows.shadowOf(actividad).getNextStartedActivity();
        assertNotNull(siguiente);
        assertEquals(WaitingActivity.class.getName(), siguiente.getComponent().getClassName());
        CallService.Peticion peticion = CallService.obtener(actividad).getPeticionActiva();
        assertNotNull(peticion);
        assertEquals("Mis plantas", peticion.getTopic());
        assertEquals(peticion.getRequestId(),
                siguiente.getStringExtra(WaitingActivity.EXTRA_REQUEST_ID));
    }

    @Test
    public void alEnviarSinRed_noSeNavegaYSeDevuelveElControl() {
        hayRed = false;
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);
        campo.setText("Mis plantas");

        boton.performClick();

        assertNull(Shadows.shadowOf(actividad).getNextStartedActivity());
        assertNull(CallService.obtener(actividad).getPeticionActiva());
        assertTrue(campo.isEnabled());
        assertTrue(boton.isEnabled());
        assertEquals(View.GONE, actividad.findViewById(R.id.textoEnviando).getVisibility());
        assertEquals(View.VISIBLE, actividad.findViewById(R.id.textoError).getVisibility());
    }

    @Test
    public void trasUnFalloDeRed_sePuedeReintentarCuandoVuelveLaRed() {
        hayRed = false;
        TopicActivity actividad = crearActividad();
        EditText campo = actividad.findViewById(R.id.campoTema);
        Button boton = actividad.findViewById(R.id.botonEnviar);
        campo.setText("Mis plantas");
        boton.performClick();

        hayRed = true;
        boton.performClick();

        Intent siguiente = Shadows.shadowOf(actividad).getNextStartedActivity();
        assertNotNull(siguiente);
        assertEquals(WaitingActivity.class.getName(), siguiente.getComponent().getClassName());
        assertEquals(View.GONE, actividad.findViewById(R.id.textoError).getVisibility());
    }
}
