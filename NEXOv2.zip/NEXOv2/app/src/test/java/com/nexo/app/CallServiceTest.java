package com.nexo.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

/**
 * Pruebas de la T3: CallService.
 * Requisitos cubiertos: RF-04, RF-05 y LC-02.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class CallServiceTest {

    private static final String NUMERO = "+34600111222";

    private CallService conRed() {
        return new CallService(() -> true, NUMERO);
    }

    private CallService sinRed() {
        return new CallService(() -> false, NUMERO);
    }

    @Test
    public void conRed_registraLaPeticionConElNumeroRegistrado() throws Exception {
        CallService.Peticion peticion = conRed().registrarPeticion("Mis plantas");

        assertEquals(NUMERO, peticion.getUserPhone());
        assertEquals("Mis plantas", peticion.getTopic());
        assertEquals(CallService.ESTADO_BUSCANDO, peticion.getStatus());
        assertEquals(120, peticion.getTimeoutSeconds());
        assertTrue(peticion.getRequestId().startsWith("req_"));
    }

    @Test
    public void laPeticionSigueElModeloJsonDelPlan() throws Exception {
        JSONObject json = conRed().registrarPeticion("Mi día").toJson();

        assertEquals(NUMERO, json.getString("user_phone"));
        assertEquals("Mi día", json.getString("topic"));
        assertEquals("searching", json.getString("status"));
        assertEquals(120, json.getInt("timeout_seconds"));
        assertTrue(json.getString("created_at").matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z"));
        assertNotNull(json.getString("request_id"));
    }

    @Test
    public void quitaLosEspaciosSobrantesDelTema() throws Exception {
        assertEquals("Mis plantas", conRed().registrarPeticion("  Mis plantas  ").getTopic());
    }

    @Test
    public void laPeticionRegistradaQuedaComoActiva() throws Exception {
        CallService servicio = conRed();

        CallService.Peticion peticion = servicio.registrarPeticion("Mis plantas");

        assertSame(peticion, servicio.getPeticionActiva());
    }

    @Test
    public void sinRed_seCancelaYNoQuedaNingunaPeticion() {
        CallService servicio = sinRed();

        try {
            servicio.registrarPeticion("Mis plantas");
            fail("Debería lanzar SinConexionException");
        } catch (CallService.SinConexionException esperado) {
            // correcto
        }

        assertNull(servicio.getPeticionActiva());
    }

    @Test
    public void siLaComprobacionDeRedFalla_seTrataComoSinRed() {
        CallService servicio = new CallService(() -> {
            throw new RuntimeException("fallo al consultar la red");
        }, NUMERO);

        try {
            servicio.registrarPeticion("Mis plantas");
            fail("Debería lanzar SinConexionException");
        } catch (CallService.SinConexionException esperado) {
            assertNull(servicio.getPeticionActiva());
        }
    }

    @Test
    public void temaNoValido_seRechaza() throws Exception {
        CallService servicio = conRed();
        String[] invalidos = {null, "", "    ", "a".repeat(101)};

        for (String tema : invalidos) {
            try {
                servicio.registrarPeticion(tema);
                fail("Debería rechazar el tema: " + tema);
            } catch (IllegalArgumentException esperado) {
                // correcto
            }
        }
        assertNull(servicio.getPeticionActiva());
    }

    @Test
    public void cancelarMarcaLaPeticionYLaQuitaDeActiva() throws Exception {
        CallService servicio = conRed();
        CallService.Peticion peticion = servicio.registrarPeticion("Mis plantas");

        servicio.cancelarPeticion(peticion);

        assertTrue(peticion.estaCancelada());
        assertFalse(CallService.ESTADO_BUSCANDO.equals(peticion.getStatus()));
        assertNull(servicio.getPeticionActiva());
    }

    @Test
    public void cancelarEsSeguroVariasVecesOConNull() throws Exception {
        CallService servicio = conRed();
        CallService.Peticion peticion = servicio.registrarPeticion("Mis plantas");

        servicio.cancelarPeticion(peticion);
        servicio.cancelarPeticion(peticion);
        servicio.cancelarPeticion(null);

        assertTrue(peticion.estaCancelada());
    }
}
