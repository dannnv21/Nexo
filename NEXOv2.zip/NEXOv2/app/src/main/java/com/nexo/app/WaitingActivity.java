package com.nexo.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/** Frame 3: búsqueda de voluntario con timeout y cancelación (T4). */
public class WaitingActivity extends AppCompatActivity {

    public static final String EXTRA_REQUEST_ID = "request_id";
    private static final String STATE_DEADLINE = "deadline_elapsed";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long deadlineElapsed;
    private boolean finalizadaPorTimeout = false;
    private boolean navegandoAFinal = false;
    private CallService.Peticion peticion;

    private final Runnable timeoutRunnable = this::finalizarPorTimeout;

    @Override
    protected void onCreate(Bundle estadoGuardado) {
        super.onCreate(estadoGuardado);
        setContentView(R.layout.activity_waiting);

        String requestId = getIntent().getStringExtra(EXTRA_REQUEST_ID);
        peticion = CallService.obtener(this).getPeticionActiva();

        // No mantener una pantalla de espera si la petición ya no existe o no coincide.
        if (peticion == null || requestId == null
                || !requestId.equals(peticion.getRequestId())) {
            abrirPantallaSinVoluntarios();
            return;
        }

        TextView tema = findViewById(R.id.textoTemaElegido);
        tema.setText(getString(R.string.espera_tema, peticion.getTopic()));

        if (estadoGuardado != null && estadoGuardado.containsKey(STATE_DEADLINE)) {
            deadlineElapsed = estadoGuardado.getLong(STATE_DEADLINE);
        } else {
            deadlineElapsed = SystemClock.elapsedRealtime()
                    + peticion.getTimeoutSeconds() * 1000L;
        }
        programarTimeoutRestante();
    }

    private void programarTimeoutRestante() {
        handler.removeCallbacks(timeoutRunnable);
        long restante = deadlineElapsed - SystemClock.elapsedRealtime();
        if (restante <= 0) {
            finalizarPorTimeout();
        } else {
            handler.postDelayed(timeoutRunnable, restante);
        }
    }

    private void finalizarPorTimeout() {
        if (isFinishing() || isDestroyed() || navegandoAFinal) return;
        finalizadaPorTimeout = true;
        navegandoAFinal = true;
        handler.removeCallbacks(timeoutRunnable);

        // La búsqueda termina y la petición deja de estar activa.
        CallService.obtener(this).cancelarPeticion(peticion);
        abrirPantallaSinVoluntarios();
    }

    private void abrirPantallaSinVoluntarios() {
        navegandoAFinal = true;
        Intent intent = new Intent(this, NoVolunteersActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putLong(STATE_DEADLINE, deadlineElapsed);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(timeoutRunnable);
        // Salir manualmente de la espera cancela la solicitud; un cambio de configuración no.
        if (!finalizadaPorTimeout && !navegandoAFinal
                && isFinishing() && !isChangingConfigurations()) {
            CallService.obtener(this).cancelarPeticion(peticion);
        }
        super.onDestroy();
    }
}
