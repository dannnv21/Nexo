package com.nexo.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

/** Frame 4: aviso cuando nadie acepta la petición dentro de los 120 segundos (T5). */
public class NoVolunteersActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle estadoGuardado) {
        super.onCreate(estadoGuardado);
        setContentView(R.layout.activity_no_volunteers);

        Button volver = findViewById(R.id.botonVolverInicio);
        volver.setOnClickListener(v -> {
            Intent inicio = new Intent(this, WelcomeActivity.class);
            inicio.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(inicio);
            finish();
        });
    }
}
