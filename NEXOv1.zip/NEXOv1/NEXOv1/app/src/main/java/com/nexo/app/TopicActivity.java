package com.nexo.app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Frame 2: Pantalla para introducir el tema de conversación.
 *
 * MARCADOR DE POSICIÓN: existe solo para que la navegación de la T1 (RF-02)
 * tenga destino. La validación, el límite de 100 caracteres y el bloqueo del
 * botón (RF-03, RF-04) se implementarán en la T2.
 */
public class TopicActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle estadoGuardado) {
        super.onCreate(estadoGuardado);
        setContentView(R.layout.activity_topic);
    }
}
